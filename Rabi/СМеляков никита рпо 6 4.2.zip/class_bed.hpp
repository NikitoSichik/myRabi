#pragma once 
#include <iostream>

class Bed {
	bool two_tiered_;
	int number_of_seats_;
	std::string material_;
	int money_;
public:
	Bed();
	void BedEdit();
	void BedPrint();
};